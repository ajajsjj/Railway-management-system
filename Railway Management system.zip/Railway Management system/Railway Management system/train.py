import tkinter as tk
from tkinter import ttk, messagebox
from database import get_connection


def open_train():

    win = tk.Toplevel()

    win.title("Train Management")

    win.geometry("1050x650")

    # =========================
    # TITLE
    # =========================

    tk.Label(
        win,
        text="TRAIN MANAGEMENT",
        font=("Arial", 20, "bold")
    ).pack(pady=15)

    # =========================
    # FORM
    # =========================

    form = tk.Frame(win)
    form.pack()

    tk.Label(
        form,
        text="Train Number"
    ).grid(row=0, column=0, padx=10, pady=8)

    number_entry = tk.Entry(
        form,
        width=25
    )
    number_entry.grid(row=0, column=1)

    tk.Label(
        form,
        text="Train Name"
    ).grid(row=0, column=2, padx=10)

    name_entry = tk.Entry(
        form,
        width=25
    )
    name_entry.grid(row=0, column=3)

    tk.Label(
        form,
        text="Train Type"
    ).grid(row=1, column=0, padx=10, pady=8)

    type_entry = tk.Entry(
        form,
        width=25
    )
    type_entry.grid(row=1, column=1)

    tk.Label(
        form,
        text="Total Seats"
    ).grid(row=1, column=2, padx=10)

    seats_entry = tk.Entry(
        form,
        width=25
    )
    seats_entry.grid(row=1, column=3)

    # =========================
    # TABLE
    # =========================

    columns = (
        "ID",
        "Train No",
        "Train Name",
        "Type",
        "Total Seats"
    )

    table = ttk.Treeview(
        win,
        columns=columns,
        show="headings",
        height=16
    )

    for col in columns:

        table.heading(
            col,
            text=col
        )

        table.column(
            col,
            width=180
        )

    table.pack(pady=20)

    # =========================
    # LOAD
    # =========================

    def load_data():

        for item in table.get_children():
            table.delete(item)

        conn = get_connection()

        if conn is None:
            return

        cursor = conn.cursor()

        cursor.execute(
            """
            SELECT train_id,
                   train_no,
                   train_name,
                   train_type,
                   total_seats
            FROM trains
            ORDER BY train_id
            """
        )

        rows = cursor.fetchall()

        for row in rows:

            table.insert(
                "",
                tk.END,
                values=row
            )

        cursor.close()
        conn.close()

    # =========================
    # CLEAR
    # =========================

    def clear():

        number_entry.delete(0, tk.END)
        name_entry.delete(0, tk.END)
        type_entry.delete(0, tk.END)
        seats_entry.delete(0, tk.END)

    # =========================
    # ADD
    # =========================

    def add_train():

        number = number_entry.get().strip()
        name = name_entry.get().strip()
        train_type = type_entry.get().strip()
        seats = seats_entry.get().strip()

        if not number or not name or not train_type or not seats:

            messagebox.showwarning(
                "Warning",
                "Please fill all fields."
            )

            return

        try:
            seats = int(seats)

            if seats <= 0:
                raise ValueError

        except:

            messagebox.showerror(
                "Error",
                "Total seats must be a positive number."
            )

            return

        conn = get_connection()

        cursor = conn.cursor()

        try:

            cursor.execute(
                """
                INSERT INTO trains
                (train_no, train_name, train_type, total_seats)
                VALUES (%s,%s,%s,%s)
                """,
                (
                    number,
                    name,
                    train_type,
                    seats
                )
            )

            conn.commit()

            messagebox.showinfo(
                "Success",
                "Train added successfully."
            )

            clear()
            load_data()

        except Exception as e:

            conn.rollback()

            messagebox.showerror(
                "Error",
                str(e)
            )

        cursor.close()
        conn.close()

    # =========================
    # SELECT
    # =========================

    def select_train(event):

        selected = table.focus()

        if not selected:
            return

        values = table.item(
            selected,
            "values"
        )

        clear()

        number_entry.insert(
            0,
            values[1]
        )

        name_entry.insert(
            0,
            values[2]
        )

        type_entry.insert(
            0,
            values[3]
        )

        seats_entry.insert(
            0,
            values[4]
        )

    # =========================
    # UPDATE
    # =========================

    def update_train():

        selected = table.focus()

        if not selected:

            messagebox.showwarning(
                "Warning",
                "Select a train first."
            )

            return

        values = table.item(
            selected,
            "values"
        )

        train_id = values[0]

        number = number_entry.get().strip()
        name = name_entry.get().strip()
        train_type = type_entry.get().strip()
        seats = seats_entry.get().strip()

        try:
            seats = int(seats)
        except:

            messagebox.showerror(
                "Error",
                "Invalid seat number."
            )

            return

        conn = get_connection()
        cursor = conn.cursor()

        try:

            cursor.execute(
                """
                UPDATE trains

                SET train_no=%s,
                    train_name=%s,
                    train_type=%s,
                    total_seats=%s

                WHERE train_id=%s
                """,
                (
                    number,
                    name,
                    train_type,
                    seats,
                    train_id
                )
            )

            conn.commit()

            messagebox.showinfo(
                "Success",
                "Train updated successfully."
            )

            clear()
            load_data()

        except Exception as e:

            conn.rollback()

            messagebox.showerror(
                "Error",
                str(e)
            )

        cursor.close()
        conn.close()

    # =========================
    # DELETE
    # =========================

    def delete_train():

        selected = table.focus()

        if not selected:

            messagebox.showwarning(
                "Warning",
                "Select a train first."
            )

            return

        values = table.item(
            selected,
            "values"
        )

        train_id = values[0]

        if not messagebox.askyesno(
            "Confirm",
            "Delete this train?"
        ):
            return

        conn = get_connection()
        cursor = conn.cursor()

        try:

            cursor.execute(
                """
                DELETE FROM trains
                WHERE train_id=%s
                """,
                (train_id,)
            )

            conn.commit()

            messagebox.showinfo(
                "Success",
                "Train deleted successfully."
            )

            clear()
            load_data()

        except Exception as e:

            conn.rollback()

            messagebox.showerror(
                "Error",
                str(e)
            )

        cursor.close()
        conn.close()

    # =========================
    # BUTTONS
    # =========================

    buttons = tk.Frame(win)
    buttons.pack()

    tk.Button(
        buttons,
        text="Add Train",
        width=15,
        command=add_train
    ).grid(row=0, column=0, padx=5)

    tk.Button(
        buttons,
        text="Update",
        width=15,
        command=update_train
    ).grid(row=0, column=1, padx=5)

    tk.Button(
        buttons,
        text="Delete",
        width=15,
        command=delete_train
    ).grid(row=0, column=2, padx=5)

    tk.Button(
        buttons,
        text="Clear",
        width=15,
        command=clear
    ).grid(row=0, column=3, padx=5)

    table.bind(
        "<ButtonRelease-1>",
        select_train
    )

    load_data()