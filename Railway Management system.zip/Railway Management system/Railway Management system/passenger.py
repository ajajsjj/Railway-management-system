import tkinter as tk
from tkinter import ttk, messagebox
from database import get_connection


def open_passenger():

    win = tk.Toplevel()
    win.title("Passenger Management")
    win.geometry("950x600")
    win.resizable(False, False)

    # =========================
    # TITLE
    # =========================

    tk.Label(
        win,
        text="PASSENGER MANAGEMENT",
        font=("Arial", 20, "bold")
    ).pack(pady=15)

    # =========================
    # FORM
    # =========================

    form = tk.Frame(win)
    form.pack(pady=10)

    # Passenger Name
    tk.Label(
        form,
        text="Passenger Name"
    ).grid(row=0, column=0, padx=10, pady=8)

    name_entry = tk.Entry(
        form,
        width=35
    )
    name_entry.grid(row=0, column=1, padx=10)

    # Phone
    tk.Label(
        form,
        text="Phone"
    ).grid(row=0, column=2, padx=10, pady=8)

    phone_entry = tk.Entry(
        form,
        width=35
    )
    phone_entry.grid(row=0, column=3, padx=10)

    # Email
    tk.Label(
        form,
        text="Email"
    ).grid(row=1, column=0, padx=10, pady=8)

    email_entry = tk.Entry(
        form,
        width=35
    )
    email_entry.grid(row=1, column=1, padx=10)

    # =========================
    # TABLE
    # =========================

    columns = (
        "ID",
        "Name",
        "Phone",
        "Email"
    )

    table = ttk.Treeview(
        win,
        columns=columns,
        show="headings",
        height=15
    )

    table.heading("ID", text="ID")
    table.heading("Name", text="Passenger Name")
    table.heading("Phone", text="Phone")
    table.heading("Email", text="Email")

    table.column("ID", width=80)
    table.column("Name", width=250)
    table.column("Phone", width=200)
    table.column("Email", width=300)

    table.pack(pady=20)

    # =========================
    # LOAD DATA
    # =========================

    def load_data():

        for item in table.get_children():
            table.delete(item)

        conn = get_connection()

        if conn is None:
            return

        cursor = conn.cursor()

        try:

            cursor.execute(
                """
                SELECT
                    passenger_id,
                    passenger_name,
                    phone,
                    email
                FROM passengers
                ORDER BY passenger_id
                """
            )

            rows = cursor.fetchall()

            for row in rows:

                table.insert(
                    "",
                    tk.END,
                    values=row
                )

        except Exception as e:

            messagebox.showerror(
                "Database Error",
                str(e)
            )

        cursor.close()
        conn.close()

    # =========================
    # CLEAR
    # =========================

    def clear():

        name_entry.delete(
            0,
            tk.END
        )

        phone_entry.delete(
            0,
            tk.END
        )

        email_entry.delete(
            0,
            tk.END
        )

    # =========================
    # ADD PASSENGER
    # =========================

    def add_passenger():

        name = name_entry.get().strip()
        phone = phone_entry.get().strip()
        email = email_entry.get().strip()

        if name == "":
            messagebox.showwarning(
                "Warning",
                "Please enter passenger name."
            )
            return

        if phone == "":
            messagebox.showwarning(
                "Warning",
                "Please enter phone number."
            )
            return

        conn = get_connection()

        if conn is None:
            return

        cursor = conn.cursor()

        try:

            cursor.execute(
                """
                INSERT INTO passengers
                (
                    passenger_name,
                    phone,
                    email
                )
                VALUES (%s, %s, %s)
                """,
                (
                    name,
                    phone,
                    email
                )
            )

            conn.commit()

            messagebox.showinfo(
                "Success",
                "Passenger added successfully."
            )

            clear()
            load_data()

        except Exception as e:

            conn.rollback()

            messagebox.showerror(
                "Error",
                str(e)
            )

        cursor.close()
        conn.close()

    # =========================
    # SELECT PASSENGER
    # =========================

    def select_passenger(event):

        selected = table.focus()

        if selected == "":
            return

        values = table.item(
            selected,
            "values"
        )

        clear()

        name_entry.insert(
            0,
            values[1]
        )

        phone_entry.insert(
            0,
            values[2]
        )

        email_entry.insert(
            0,
            values[3]
        )

    # =========================
    # UPDATE PASSENGER
    # =========================

    def update_passenger():

        selected = table.focus()

        if selected == "":

            messagebox.showwarning(
                "Warning",
                "Please select a passenger."
            )

            return

        values = table.item(
            selected,
            "values"
        )

        passenger_id = values[0]

        name = name_entry.get().strip()
        phone = phone_entry.get().strip()
        email = email_entry.get().strip()

        if name == "" or phone == "":

            messagebox.showwarning(
                "Warning",
                "Name and phone are required."
            )

            return

        conn = get_connection()

        if conn is None:
            return

        cursor = conn.cursor()

        try:

            cursor.execute(
                """
                UPDATE passengers

                SET passenger_name = %s,
                    phone = %s,
                    email = %s

                WHERE passenger_id = %s
                """,
                (
                    name,
                    phone,
                    email,
                    passenger_id
                )
            )

            conn.commit()

            messagebox.showinfo(
                "Success",
                "Passenger updated successfully."
            )

            clear()
            load_data()

        except Exception as e:

            conn.rollback()

            messagebox.showerror(
                "Error",
                str(e)
            )

        cursor.close()
        conn.close()

    # =========================
    # DELETE PASSENGER
    # =========================

    def delete_passenger():

        selected = table.focus()

        if selected == "":

            messagebox.showwarning(
                "Warning",
                "Please select a passenger."
            )

            return

        values = table.item(
            selected,
            "values"
        )

        passenger_id = values[0]

        confirm = messagebox.askyesno(
            "Confirm Delete",
            "Are you sure you want to delete this passenger?"
        )

        if not confirm:
            return

        conn = get_connection()

        if conn is None:
            return

        cursor = conn.cursor()

        try:

            cursor.execute(
                """
                DELETE FROM passengers
                WHERE passenger_id = %s
                """,
                (passenger_id,)
            )

            conn.commit()

            messagebox.showinfo(
                "Success",
                "Passenger deleted successfully."
            )

            clear()
            load_data()

        except Exception as e:

            conn.rollback()

            messagebox.showerror(
                "Error",
                str(e)
            )

        cursor.close()
        conn.close()

    # =========================
    # BUTTONS
    # =========================

    button_frame = tk.Frame(win)
    button_frame.pack(pady=5)

    tk.Button(
        button_frame,
        text="Add",
        width=15,
        command=add_passenger
    ).grid(
        row=0,
        column=0,
        padx=5
    )

    tk.Button(
        button_frame,
        text="Update",
        width=15,
        command=update_passenger
    ).grid(
        row=0,
        column=1,
        padx=5
    )

    tk.Button(
        button_frame,
        text="Delete",
        width=15,
        command=delete_passenger
    ).grid(
        row=0,
        column=2,
        padx=5
    )

    tk.Button(
        button_frame,
        text="Clear",
        width=15,
        command=clear
    ).grid(
        row=0,
        column=3,
        padx=5
    )

    # Row select
    table.bind(
        "<ButtonRelease-1>",
        select_passenger
    )

    # Initial load
    load_data()