import tkinter as tk
from tkinter import ttk, messagebox
from database import get_connection


def open_schedule():

    win = tk.Toplevel()

    win.title("Schedule Management")

    win.geometry("1100x650")

    tk.Label(
        win,
        text="SCHEDULE MANAGEMENT",
        font=("Arial", 20, "bold")
    ).pack(pady=15)

    # =========================
    # DATA MAPS
    # =========================

    train_map = {}
    route_map = {}

    # =========================
    # FORM
    # =========================

    form = tk.Frame(win)
    form.pack()

    tk.Label(
        form,
        text="Train"
    ).grid(row=0, column=0, padx=10, pady=8)

    train_combo = ttk.Combobox(
        form,
        width=35,
        state="readonly"
    )

    train_combo.grid(row=0, column=1)

    tk.Label(
        form,
        text="Route"
    ).grid(row=0, column=2, padx=10)

    route_combo = ttk.Combobox(
        form,
        width=35,
        state="readonly"
    )

    route_combo.grid(row=0, column=3)

    tk.Label(
        form,
        text="Travel Date (YYYY-MM-DD)"
    ).grid(row=1, column=0, padx=10, pady=8)

    date_entry = tk.Entry(
        form,
        width=38
    )

    date_entry.grid(row=1, column=1)

    tk.Label(
        form,
        text="Departure Time"
    ).grid(row=1, column=2, padx=10)

    departure_entry = tk.Entry(
        form,
        width=38
    )

    departure_entry.grid(row=1, column=3)

    tk.Label(
        form,
        text="Arrival Time"
    ).grid(row=2, column=0, padx=10, pady=8)

    arrival_entry = tk.Entry(
        form,
        width=38
    )

    arrival_entry.grid(row=2, column=1)

    # =========================
    # LOAD TRAINS
    # =========================

    def load_trains():

        train_map.clear()

        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute(
            """
            SELECT train_id,
                   train_no,
                   train_name
            FROM trains
            ORDER BY train_no
            """
        )

        rows = cursor.fetchall()

        values = []

        for train_id, train_no, train_name in rows:

            display = (
                train_no
                + " - "
                + train_name
            )

            train_map[display] = train_id

            values.append(display)

        train_combo["values"] = values

        cursor.close()
        conn.close()

    # =========================
    # LOAD ROUTES
    # =========================

    def load_routes():

        route_map.clear()

        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute(
            """
            SELECT
                r.route_id,
                s1.station_name,
                s2.station_name

            FROM routes r

            JOIN stations s1
                ON r.source_id=s1.station_id

            JOIN stations s2
                ON r.destination_id=s2.station_id
            """
        )

        rows = cursor.fetchall()

        values = []

        for route_id, source, destination in rows:

            display = (
                source
                + " -> "
                + destination
            )

            route_map[display] = route_id

            values.append(display)

        route_combo["values"] = values

        cursor.close()
        conn.close()

    # =========================
    # TABLE
    # =========================

    columns = (
        "ID",
        "Train",
        "Source",
        "Destination",
        "Date",
        "Departure",
        "Arrival"
    )

    table = ttk.Treeview(
        win,
        columns=columns,
        show="headings",
        height=14
    )

    for col in columns:

        table.heading(
            col,
            text=col
        )

        table.column(
            col,
            width=145
        )

    table.pack(pady=20)

    # =========================
    # LOAD DATA
    # =========================

    def load_data():

        for item in table.get_children():
            table.delete(item)

        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute(
            """
            SELECT
                sc.schedule_id,
                t.train_no,
                s1.station_name,
                s2.station_name,
                sc.travel_date,
                sc.departure_time,
                sc.arrival_time

            FROM schedules sc

            JOIN trains t
                ON sc.train_id=t.train_id

            JOIN routes r
                ON sc.route_id=r.route_id

            JOIN stations s1
                ON r.source_id=s1.station_id

            JOIN stations s2
                ON r.destination_id=s2.station_id

            ORDER BY sc.travel_date
            """
        )

        rows = cursor.fetchall()

        for row in rows:

            table.insert(
                "",
                tk.END,
                values=row
            )

        cursor.close()
        conn.close()

    # =========================
    # CLEAR
    # =========================

    def clear():

        train_combo.set("")
        route_combo.set("")

        date_entry.delete(
            0,
            tk.END
        )

        departure_entry.delete(
            0,
            tk.END
        )

        arrival_entry.delete(
            0,
            tk.END
        )

    # =========================
    # ADD
    # =========================

    def add_schedule():

        train = train_combo.get()
        route = route_combo.get()
        date = date_entry.get().strip()
        departure = departure_entry.get().strip()
        arrival = arrival_entry.get().strip()

        if not train or not route or not date or not departure or not arrival:

            messagebox.showwarning(
                "Warning",
                "Please fill all fields."
            )

            return

        conn = get_connection()
        cursor = conn.cursor()

        try:

            cursor.execute(
                """
                INSERT INTO schedules
                (
                    train_id,
                    route_id,
                    travel_date,
                    departure_time,
                    arrival_time
                )

                VALUES (%s,%s,%s,%s,%s)
                """,
                (
                    train_map[train],
                    route_map[route],
                    date,
                    departure,
                    arrival
                )
            )

            conn.commit()

            messagebox.showinfo(
                "Success",
                "Schedule added successfully."
            )

            clear()
            load_data()

        except Exception as e:

            conn.rollback()

            messagebox.showerror(
                "Error",
                str(e)
            )

        cursor.close()
        conn.close()

    # =========================
    # SELECT
    # =========================

    def select_schedule(event):

        selected = table.focus()

        if not selected:
            return

        values = table.item(
            selected,
            "values"
        )

        # Find train
        for key in train_map:

            if key.startswith(
                str(values[1]) + " - "
            ):

                train_combo.set(key)
                break

        route_text = (
            str(values[2])
            + " -> "
            + str(values[3])
        )

        route_combo.set(route_text)

        date_entry.delete(0, tk.END)
        date_entry.insert(0, values[4])

        departure_entry.delete(0, tk.END)
        departure_entry.insert(0, values[5])

        arrival_entry.delete(0, tk.END)
        arrival_entry.insert(0, values[6])

    # =========================
    # UPDATE
    # =========================

    def update_schedule():

        selected = table.focus()

        if not selected:

            messagebox.showwarning(
                "Warning",
                "Select a schedule first."
            )

            return

        values = table.item(
            selected,
            "values"
        )

        schedule_id = values[0]

        train = train_combo.get()
        route = route_combo.get()
        date = date_entry.get().strip()
        departure = departure_entry.get().strip()
        arrival = arrival_entry.get().strip()

        conn = get_connection()
        cursor = conn.cursor()

        try:

            cursor.execute(
                """
                UPDATE schedules

                SET train_id=%s,
                    route_id=%s,
                    travel_date=%s,
                    departure_time=%s,
                    arrival_time=%s

                WHERE schedule_id=%s
                """,
                (
                    train_map[train],
                    route_map[route],
                    date,
                    departure,
                    arrival,
                    schedule_id
                )
            )

            conn.commit()

            messagebox.showinfo(
                "Success",
                "Schedule updated successfully."
            )

            clear()
            load_data()

        except Exception as e:

            conn.rollback()

            messagebox.showerror(
                "Error",
                str(e)
            )

        cursor.close()
        conn.close()

    # =========================
    # DELETE
    # =========================

    def delete_schedule():

        selected = table.focus()

        if not selected:
            return

        values = table.item(
            selected,
            "values"
        )

        schedule_id = values[0]

        if not messagebox.askyesno(
            "Confirm",
            "Delete this schedule?"
        ):
            return

        conn = get_connection()
        cursor = conn.cursor()

        try:

            cursor.execute(
                """
                DELETE FROM schedules
                WHERE schedule_id=%s
                """,
                (schedule_id,)
            )

            conn.commit()

            messagebox.showinfo(
                "Success",
                "Schedule deleted successfully."
            )

            clear()
            load_data()

        except Exception as e:

            conn.rollback()

            messagebox.showerror(
                "Error",
                str(e)
            )

        cursor.close()
        conn.close()

    # =========================
    # BUTTONS
    # =========================

    buttons = tk.Frame(win)
    buttons.pack()

    tk.Button(
        buttons,
        text="Add Schedule",
        width=16,
        command=add_schedule
    ).grid(row=0, column=0, padx=5)

    tk.Button(
        buttons,
        text="Update",
        width=16,
        command=update_schedule
    ).grid(row=0, column=1, padx=5)

    tk.Button(
        buttons,
        text="Delete",
        width=16,
        command=delete_schedule
    ).grid(row=0, column=2, padx=5)

    tk.Button(
        buttons,
        text="Clear",
        width=16,
        command=clear
    ).grid(row=0, column=3, padx=5)

    table.bind(
        "<ButtonRelease-1>",
        select_schedule
    )

    load_trains()
    load_routes()
    load_data()