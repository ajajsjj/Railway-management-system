import tkinter as tk
from tkinter import ttk, messagebox
from database import get_connection


def open_report():

    win = tk.Toplevel()
    win.title("Reports")
    win.geometry("1000x650")
    win.resizable(False, False)

    tk.Label(
        win,
        text="REPORTS",
        font=("Arial", 20, "bold")
    ).pack(pady=15)

    # =========================
    # SUMMARY CARDS
    # =========================

    summary_frame = tk.Frame(win)
    summary_frame.pack(pady=10)

    total_bookings_label = tk.Label(
        summary_frame,
        text="Total Bookings: -",
        font=("Arial", 13, "bold"),
        padx=20
    )
    total_bookings_label.grid(row=0, column=0, padx=15)

    total_revenue_label = tk.Label(
        summary_frame,
        text="Total Revenue: -",
        font=("Arial", 13, "bold"),
        padx=20
    )
    total_revenue_label.grid(row=0, column=1, padx=15)

    cancelled_label = tk.Label(
        summary_frame,
        text="Cancelled Tickets: -",
        font=("Arial", 13, "bold"),
        padx=20
    )
    cancelled_label.grid(row=0, column=2, padx=15)

    # =========================
    # NOTEBOOK (TABS)
    # =========================

    notebook = ttk.Notebook(win)
    notebook.pack(
        fill="both",
        expand=True,
        padx=15,
        pady=15
    )

    # ---- Tab 1: Revenue by Train ----

    train_tab = tk.Frame(notebook)
    notebook.add(train_tab, text="Revenue by Train")

    train_columns = ("Train No", "Train Name", "Tickets Sold", "Revenue")

    train_table = ttk.Treeview(
        train_tab,
        columns=train_columns,
        show="headings",
        height=15
    )

    for col in train_columns:
        train_table.heading(col, text=col)
        train_table.column(col, width=200)

    train_table.pack(fill="both", expand=True, padx=10, pady=10)

    # ---- Tab 2: Revenue by Route ----

    route_tab = tk.Frame(notebook)
    notebook.add(route_tab, text="Revenue by Route")

    route_columns = ("Source", "Destination", "Tickets Sold", "Revenue")

    route_table = ttk.Treeview(
        route_tab,
        columns=route_columns,
        show="headings",
        height=15
    )

    for col in route_columns:
        route_table.heading(col, text=col)
        route_table.column(col, width=200)

    route_table.pack(fill="both", expand=True, padx=10, pady=10)

    # =========================
    # LOAD REPORT DATA
    # =========================

    def load_reports():

        conn = get_connection()

        if conn is None:
            messagebox.showerror(
                "Error",
                "Could not connect to database."
            )
            return

        cursor = conn.cursor()

        try:

            # ---- Summary: total bookings + revenue (confirmed only) ----

            cursor.execute(
                """
                SELECT
                    COUNT(*),
                    COALESCE(SUM(amount), 0)
                FROM bookings
                WHERE status = 'Confirmed'
                """
            )

            total_bookings, total_revenue = cursor.fetchone()

            total_bookings_label.config(
                text="Total Bookings: " + str(total_bookings)
            )

            total_revenue_label.config(
                text="Total Revenue: " + str(total_revenue)
            )

            # ---- Summary: cancelled tickets ----

            cursor.execute(
                """
                SELECT COUNT(*)
                FROM bookings
                WHERE status = 'Cancelled'
                """
            )

            cancelled_count = cursor.fetchone()[0]

            cancelled_label.config(
                text="Cancelled Tickets: " + str(cancelled_count)
            )

            # ---- Revenue by Train ----

            for item in train_table.get_children():
                train_table.delete(item)

            cursor.execute(
                """
                SELECT
                    t.train_no,
                    t.train_name,
                    COUNT(b.booking_id),
                    COALESCE(SUM(b.amount), 0)

                FROM trains t

                LEFT JOIN schedules sc
                    ON sc.train_id = t.train_id

                LEFT JOIN bookings b
                    ON b.schedule_id = sc.schedule_id
                    AND b.status = 'Confirmed'

                GROUP BY t.train_id, t.train_no, t.train_name
                ORDER BY SUM(b.amount) DESC
                """
            )

            for row in cursor.fetchall():
                train_table.insert("", tk.END, values=row)

            # ---- Revenue by Route ----

            for item in route_table.get_children():
                route_table.delete(item)

            cursor.execute(
                """
                SELECT
                    s1.station_name,
                    s2.station_name,
                    COUNT(b.booking_id),
                    COALESCE(SUM(b.amount), 0)

                FROM routes r

                JOIN stations s1
                    ON r.source_id = s1.station_id

                JOIN stations s2
                    ON r.destination_id = s2.station_id

                LEFT JOIN schedules sc
                    ON sc.route_id = r.route_id

                LEFT JOIN bookings b
                    ON b.schedule_id = sc.schedule_id
                    AND b.status = 'Confirmed'

                GROUP BY r.route_id, s1.station_name, s2.station_name
                ORDER BY SUM(b.amount) DESC
                """
            )

            for row in cursor.fetchall():
                route_table.insert("", tk.END, values=row)

        except Exception as e:

            messagebox.showerror(
                "Error",
                str(e)
            )

        cursor.close()
        conn.close()

    # =========================
    # REFRESH BUTTON
    # =========================

    tk.Button(
        win,
        text="Refresh",
        width=15,
        command=load_reports
    ).pack(pady=5)

    load_reports()