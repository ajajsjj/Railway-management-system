import tkinter as tk
from tkinter import ttk, messagebox
from database import get_connection


def open_route():

    win = tk.Toplevel()
    win.title("Route Management")
    win.geometry("950x600")
    win.resizable(False, False)

    tk.Label(
        win,
        text="ROUTE MANAGEMENT",
        font=("Arial", 20, "bold")
    ).pack(pady=15)

    # =========================
    # MAP: display text -> station_id
    # =========================

    station_map = {}

    # =========================
    # FORM
    # =========================

    form = tk.Frame(win)
    form.pack(pady=10)

    tk.Label(
        form,
        text="Source Station"
    ).grid(row=0, column=0, padx=10, pady=8)

    source_combo = ttk.Combobox(
        form,
        width=35,
        state="readonly"
    )
    source_combo.grid(row=0, column=1, padx=10)

    tk.Label(
        form,
        text="Destination Station"
    ).grid(row=1, column=0, padx=10, pady=8)

    destination_combo = ttk.Combobox(
        form,
        width=35,
        state="readonly"
    )
    destination_combo.grid(row=1, column=1, padx=10)

    tk.Label(
        form,
        text="Distance (km)"
    ).grid(row=2, column=0, padx=10, pady=8)

    distance_entry = tk.Entry(
        form,
        width=38
    )
    distance_entry.grid(row=2, column=1, padx=10)

    # =========================
    # TABLE
    # =========================

    columns = (
        "ID",
        "Source",
        "Destination",
        "Distance (km)"
    )

    table = ttk.Treeview(
        win,
        columns=columns,
        show="headings",
        height=14
    )

    for col in columns:
        table.heading(col, text=col)
        table.column(col, width=210)

    table.pack(pady=20)

    # =========================
    # LOAD STATIONS INTO DROPDOWNS
    # =========================

    def load_stations():

        station_map.clear()

        conn = get_connection()

        if conn is None:
            return

        cursor = conn.cursor()

        cursor.execute(
            """
            SELECT station_id, station_name, city
            FROM stations
            ORDER BY station_name
            """
        )

        rows = cursor.fetchall()

        values = []

        for station_id, name, city in rows:

            display = name + " (" + city + ")"

            station_map[display] = station_id

            values.append(display)

        source_combo["values"] = values
        destination_combo["values"] = values

        cursor.close()
        conn.close()

    # =========================
    # LOAD ROUTES INTO TABLE
    # =========================

    def load_data():

        for item in table.get_children():
            table.delete(item)

        conn = get_connection()

        if conn is None:
            return

        cursor = conn.cursor()

        cursor.execute(
            """
            SELECT
                r.route_id,
                s1.station_name,
                s2.station_name,
                r.distance

            FROM routes r

            JOIN stations s1
                ON r.source_id = s1.station_id

            JOIN stations s2
                ON r.destination_id = s2.station_id

            ORDER BY r.route_id
            """
        )

        rows = cursor.fetchall()

        for row in rows:

            table.insert(
                "",
                tk.END,
                values=row
            )

        cursor.close()
        conn.close()

    # =========================
    # CLEAR
    # =========================

    def clear():

        source_combo.set("")
        destination_combo.set("")

        distance_entry.delete(
            0,
            tk.END
        )

    # =========================
    # ADD ROUTE
    # =========================

    def add_route():

        source = source_combo.get()
        destination = destination_combo.get()
        distance = distance_entry.get().strip()

        if not source or not destination:

            messagebox.showwarning(
                "Warning",
                "Please select source and destination station."
            )

            return

        if source == destination:

            messagebox.showwarning(
                "Warning",
                "Source and destination cannot be the same."
            )

            return

        if not distance:

            messagebox.showwarning(
                "Warning",
                "Please enter distance."
            )

            return

        try:

            distance_value = float(distance)

            if distance_value <= 0:
                raise ValueError

        except:

            messagebox.showerror(
                "Error",
                "Distance must be a positive number."
            )

            return

        source_id = station_map[source]
        destination_id = station_map[destination]

        conn = get_connection()

        if conn is None:
            return

        cursor = conn.cursor()

        try:

            cursor.execute(
                """
                INSERT INTO routes
                (source_id, destination_id, distance)
                VALUES (%s, %s, %s)
                """,
                (
                    source_id,
                    destination_id,
                    distance_value
                )
            )

            conn.commit()

            messagebox.showinfo(
                "Success",
                "Route added successfully."
            )

            clear()
            load_data()

        except Exception as e:

            conn.rollback()

            messagebox.showerror(
                "Error",
                str(e)
            )

        cursor.close()
        conn.close()

    # =========================
    # SELECT ROW
    # =========================

    def select_route(event):

        selected = table.focus()

        if selected == "":
            return

        values = table.item(
            selected,
            "values"
        )

        clear()

        # Find matching dropdown text for source/destination station names
        for key in station_map:

            if key.startswith(str(values[1]) + " ("):
                source_combo.set(key)

            if key.startswith(str(values[2]) + " ("):
                destination_combo.set(key)

        distance_entry.insert(
            0,
            values[3]
        )

    # =========================
    # UPDATE ROUTE
    # =========================

    def update_route():

        selected = table.focus()

        if selected == "":

            messagebox.showwarning(
                "Warning",
                "Select a route first."
            )

            return

        values = table.item(
            selected,
            "values"
        )

        route_id = values[0]

        source = source_combo.get()
        destination = destination_combo.get()
        distance = distance_entry.get().strip()

        if not source or not destination or not distance:

            messagebox.showwarning(
                "Warning",
                "Please fill all fields."
            )

            return

        try:
            distance_value = float(distance)
        except:

            messagebox.showerror(
                "Error",
                "Invalid distance."
            )

            return

        source_id = station_map[source]
        destination_id = station_map[destination]

        conn = get_connection()
        cursor = conn.cursor()

        try:

            cursor.execute(
                """
                UPDATE routes

                SET source_id=%s,
                    destination_id=%s,
                    distance=%s

                WHERE route_id=%s
                """,
                (
                    source_id,
                    destination_id,
                    distance_value,
                    route_id
                )
            )

            conn.commit()

            messagebox.showinfo(
                "Success",
                "Route updated successfully."
            )

            clear()
            load_data()

        except Exception as e:

            conn.rollback()

            messagebox.showerror(
                "Error",
                str(e)
            )

        cursor.close()
        conn.close()

    # =========================
    # DELETE ROUTE
    # =========================

    def delete_route():

        selected = table.focus()

        if selected == "":

            messagebox.showwarning(
                "Warning",
                "Select a route first."
            )

            return

        values = table.item(
            selected,
            "values"
        )

        route_id = values[0]

        confirm = messagebox.askyesno(
            "Confirm Delete",
            "Are you sure you want to delete this route?"
        )

        if not confirm:
            return

        conn = get_connection()
        cursor = conn.cursor()

        try:

            cursor.execute(
                """
                DELETE FROM routes
                WHERE route_id=%s
                """,
                (route_id,)
            )

            conn.commit()

            messagebox.showinfo(
                "Success",
                "Route deleted successfully."
            )

            clear()
            load_data()

        except Exception as e:

            conn.rollback()

            messagebox.showerror(
                "Error",
                str(e)
            )

        cursor.close()
        conn.close()

    # =========================
    # BUTTONS
    # =========================

    buttons = tk.Frame(win)
    buttons.pack(pady=5)

    tk.Button(
        buttons,
        text="Add",
        width=15,
        command=add_route
    ).grid(row=0, column=0, padx=5)

    tk.Button(
        buttons,
        text="Update",
        width=15,
        command=update_route
    ).grid(row=0, column=1, padx=5)

    tk.Button(
        buttons,
        text="Delete",
        width=15,
        command=delete_route
    ).grid(row=0, column=2, padx=5)

    tk.Button(
        buttons,
        text="Clear",
        width=15,
        command=clear
    ).grid(row=0, column=3, padx=5)

    table.bind(
        "<ButtonRelease-1>",
        select_route
    )

    load_stations()
    load_data()