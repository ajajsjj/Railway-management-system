import tkinter as tk
from tkinter import ttk, messagebox
from database import get_connection


def open_booking():

    win = tk.Toplevel()

    win.title("Ticket Booking")

    win.geometry("800x600")

    tk.Label(
        win,
        text="TICKET BOOKING",
        font=("Arial", 20, "bold")
    ).pack(pady=20)

    # =========================
    # MAPS
    # =========================

    passenger_map = {}
    schedule_map = {}

    # =========================
    # FORM
    # =========================

    form = tk.Frame(win)
    form.pack(pady=10)

    tk.Label(
        form,
        text="Passenger"
    ).grid(row=0, column=0, padx=10, pady=10)

    passenger_combo = ttk.Combobox(
        form,
        width=45,
        state="readonly"
    )

    passenger_combo.grid(row=0, column=1)

    tk.Label(
        form,
        text="Schedule"
    ).grid(row=1, column=0, padx=10, pady=10)

    schedule_combo = ttk.Combobox(
        form,
        width=45,
        state="readonly"
    )

    schedule_combo.grid(row=1, column=1)

    tk.Label(
        form,
        text="Seat Number"
    ).grid(row=2, column=0, padx=10, pady=10)

    seat_entry = tk.Entry(
        form,
        width=48
    )

    seat_entry.grid(row=2, column=1)

    tk.Label(
        form,
        text="Fare"
    ).grid(row=3, column=0, padx=10, pady=10)

    amount_entry = tk.Entry(
        form,
        width=48
    )

    amount_entry.grid(row=3, column=1)

    # =========================
    # LOAD PASSENGERS
    # =========================

    def load_passengers():

        passenger_map.clear()

        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute(
            """
            SELECT
                passenger_id,
                passenger_name,
                phone

            FROM passengers

            ORDER BY passenger_name
            """
        )

        rows = cursor.fetchall()

        values = []

        for pid, name, phone in rows:

            display = (
                str(pid)
                + " - "
                + name
                + " - "
                + phone
            )

            passenger_map[display] = pid

            values.append(display)

        passenger_combo["values"] = values

        cursor.close()
        conn.close()

    # =========================
    # LOAD SCHEDULES
    # =========================

    def load_schedules():

        schedule_map.clear()

        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute(
            """
            SELECT
                sc.schedule_id,
                t.train_no,
                t.train_name,
                s1.station_name,
                s2.station_name,
                sc.travel_date,
                sc.departure_time

            FROM schedules sc

            JOIN trains t
                ON sc.train_id=t.train_id

            JOIN routes r
                ON sc.route_id=r.route_id

            JOIN stations s1
                ON r.source_id=s1.station_id

            JOIN stations s2
                ON r.destination_id=s2.station_id

            ORDER BY sc.travel_date
            """
        )

        rows = cursor.fetchall()

        values = []

        for row in rows:

            schedule_id = row[0]

            display = (
                str(row[1])
                + " - "
                + row[2]
                + " | "
                + row[3]
                + " -> "
                + row[4]
                + " | "
                + str(row[5])
                + " | "
                + str(row[6])
            )

            schedule_map[display] = schedule_id

            values.append(display)

        schedule_combo["values"] = values

        cursor.close()
        conn.close()

    # =========================
    # BOOK
    # =========================

    def book_ticket():

        passenger = passenger_combo.get()
        schedule = schedule_combo.get()
        seat = seat_entry.get().strip()
        amount = amount_entry.get().strip()

        if not passenger or not schedule or not seat or not amount:

            messagebox.showwarning(
                "Warning",
                "Please fill all fields."
            )

            return

        try:

            amount_value = float(amount)

            if amount_value <= 0:
                raise ValueError

        except:

            messagebox.showerror(
                "Error",
                "Invalid fare."
            )

            return

        passenger_id = passenger_map[passenger]
        schedule_id = schedule_map[schedule]

        conn = get_connection()
        cursor = conn.cursor()

        try:

            # =========================
            # CHECK DUPLICATE SEAT
            # =========================

            cursor.execute(
                """
                SELECT booking_id

                FROM bookings

                WHERE schedule_id=%s
                AND seat_no=%s
                AND status='Confirmed'
                """,
                (
                    schedule_id,
                    seat
                )
            )

            existing = cursor.fetchone()

            if existing:

                messagebox.showerror(
                    "Seat Unavailable",
                    "This seat is already booked."
                )

                cursor.close()
                conn.close()

                return

            # =========================
            # INSERT BOOKING
            # =========================

            cursor.execute(
                """
                INSERT INTO bookings
                (
                    passenger_id,
                    schedule_id,
                    seat_no,
                    amount,
                    status
                )

                VALUES (%s,%s,%s,%s,'Confirmed')
                """,
                (
                    passenger_id,
                    schedule_id,
                    seat,
                    amount_value
                )
            )

            booking_id = cursor.lastrowid

            conn.commit()

            messagebox.showinfo(
                "Booking Successful",
                "Ticket booked successfully!\n\n"
                + "Booking ID: "
                + str(booking_id)
                + "\nSeat: "
                + seat
            )

            passenger_combo.set("")
            schedule_combo.set("")

            seat_entry.delete(
                0,
                tk.END
            )

            amount_entry.delete(
                0,
                tk.END
            )

        except Exception as e:

            conn.rollback()

            messagebox.showerror(
                "Error",
                str(e)
            )

        cursor.close()
        conn.close()

    # =========================
    # BUTTON
    # =========================

    tk.Button(
        win,
        text="BOOK TICKET",
        width=25,
        height=2,
        font=("Arial", 12, "bold"),
        command=book_ticket
    ).pack(pady=30)

    load_passengers()
    load_schedules()