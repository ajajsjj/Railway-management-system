import tkinter as tk
from tkinter import ttk, messagebox
from database import get_connection


# =========================================================
# SEARCH TRAIN
# =========================================================

def search_train():

    win = tk.Toplevel()

    win.title("Search Train")

    win.geometry("1150x600")

    win.resizable(False, False)

    # =========================
    # TITLE
    # =========================

    tk.Label(
        win,
        text="SEARCH TRAIN",
        font=("Arial", 20, "bold")
    ).pack(pady=15)

    # =========================
    # SEARCH FORM
    # =========================

    form = tk.Frame(win)
    form.pack(pady=10)

    tk.Label(
        form,
        text="Source"
    ).grid(
        row=0,
        column=0,
        padx=10
    )

    source_entry = tk.Entry(
        form,
        width=25
    )

    source_entry.grid(
        row=0,
        column=1,
        padx=10
    )

    tk.Label(
        form,
        text="Destination"
    ).grid(
        row=0,
        column=2,
        padx=10
    )

    destination_entry = tk.Entry(
        form,
        width=25
    )

    destination_entry.grid(
        row=0,
        column=3,
        padx=10
    )

    # =========================
    # TABLE
    # =========================

    columns = (
        "Train No",
        "Train Name",
        "Source",
        "Destination",
        "Date",
        "Departure",
        "Arrival"
    )

    table = ttk.Treeview(
        win,
        columns=columns,
        show="headings",
        height=18
    )

    table.heading(
        "Train No",
        text="Train No"
    )

    table.heading(
        "Train Name",
        text="Train Name"
    )

    table.heading(
        "Source",
        text="Source"
    )

    table.heading(
        "Destination",
        text="Destination"
    )

    table.heading(
        "Date",
        text="Date"
    )

    table.heading(
        "Departure",
        text="Departure"
    )

    table.heading(
        "Arrival",
        text="Arrival"
    )

    table.column(
        "Train No",
        width=110
    )

    table.column(
        "Train Name",
        width=180
    )

    table.column(
        "Source",
        width=160
    )

    table.column(
        "Destination",
        width=160
    )

    table.column(
        "Date",
        width=130
    )

    table.column(
        "Departure",
        width=120
    )

    table.column(
        "Arrival",
        width=120
    )

    table.pack(
        pady=20,
        padx=10
    )

    # =========================
    # SEARCH FUNCTION
    # =========================

    def search():

        source = source_entry.get().strip()

        destination = destination_entry.get().strip()

        # Clear previous results

        for item in table.get_children():

            table.delete(item)

        conn = get_connection()

        if conn is None:
            return

        cursor = conn.cursor()

        try:

            query = """
            SELECT
                t.train_no,
                t.train_name,
                s1.station_name,
                s2.station_name,
                sc.travel_date,
                sc.departure_time,
                sc.arrival_time

            FROM schedules sc

            INNER JOIN trains t
                ON sc.train_id = t.train_id

            INNER JOIN routes r
                ON sc.route_id = r.route_id

            INNER JOIN stations s1
                ON r.source_id = s1.station_id

            INNER JOIN stations s2
                ON r.destination_id = s2.station_id

            WHERE s1.station_name LIKE %s
            AND s2.station_name LIKE %s

            ORDER BY sc.travel_date
            """

            cursor.execute(
                query,
                (
                    "%" + source + "%",
                    "%" + destination + "%"
                )
            )

            rows = cursor.fetchall()

            if len(rows) == 0:

                messagebox.showinfo(
                    "No Result",
                    "No train found."
                )

            for row in rows:

                table.insert(
                    "",
                    tk.END,
                    values=row
                )

        except Exception as e:

            messagebox.showerror(
                "Error",
                str(e)
            )

        cursor.close()
        conn.close()

    # =========================
    # SEARCH BUTTON
    # =========================

    tk.Button(
        form,
        text="SEARCH",
        width=15,
        command=search
    ).grid(
        row=0,
        column=4,
        padx=10
    )


# =========================================================
# VIEW ALL TICKETS
# =========================================================

def view_tickets():

    win = tk.Toplevel()

    win.title("Ticket Information")

    win.geometry("1250x650")

    win.resizable(False, False)

    # =========================
    # TITLE
    # =========================

    tk.Label(
        win,
        text="TICKET INFORMATION",
        font=("Arial", 20, "bold")
    ).pack(pady=15)

    # =========================
    # TABLE
    # =========================

    columns = (
        "Booking ID",
        "Passenger",
        "Train",
        "Source",
        "Destination",
        "Date",
        "Seat",
        "Amount",
        "Status"
    )

    table = ttk.Treeview(
        win,
        columns=columns,
        show="headings",
        height=22
    )

    table.heading(
        "Booking ID",
        text="Booking ID"
    )

    table.heading(
        "Passenger",
        text="Passenger"
    )

    table.heading(
        "Train",
        text="Train"
    )

    table.heading(
        "Source",
        text="Source"
    )

    table.heading(
        "Destination",
        text="Destination"
    )

    table.heading(
        "Date",
        text="Date"
    )

    table.heading(
        "Seat",
        text="Seat"
    )

    table.heading(
        "Amount",
        text="Amount"
    )

    table.heading(
        "Status",
        text="Status"
    )

    table.column(
        "Booking ID",
        width=90
    )

    table.column(
        "Passenger",
        width=150
    )

    table.column(
        "Train",
        width=150
    )

    table.column(
        "Source",
        width=140
    )

    table.column(
        "Destination",
        width=140
    )

    table.column(
        "Date",
        width=110
    )

    table.column(
        "Seat",
        width=80
    )

    table.column(
        "Amount",
        width=90
    )

    table.column(
        "Status",
        width=100
    )

    table.pack(
        padx=10,
        pady=20
    )

    # =========================
    # LOAD TICKETS
    # =========================

    def load_tickets():

        for item in table.get_children():

            table.delete(item)

        conn = get_connection()

        if conn is None:
            return

        cursor = conn.cursor()

        try:

            query = """
            SELECT
                b.booking_id,
                p.passenger_name,
                t.train_name,
                s1.station_name,
                s2.station_name,
                sc.travel_date,
                b.seat_no,
                b.amount,
                b.status

            FROM bookings b

            INNER JOIN passengers p
                ON b.passenger_id = p.passenger_id

            INNER JOIN schedules sc
                ON b.schedule_id = sc.schedule_id

            INNER JOIN trains t
                ON sc.train_id = t.train_id

            INNER JOIN routes r
                ON sc.route_id = r.route_id

            INNER JOIN stations s1
                ON r.source_id = s1.station_id

            INNER JOIN stations s2
                ON r.destination_id = s2.station_id

            ORDER BY b.booking_id DESC
            """

            cursor.execute(query)

            rows = cursor.fetchall()

            for row in rows:

                table.insert(
                    "",
                    tk.END,
                    values=row
                )

        except Exception as e:

            messagebox.showerror(
                "Error",
                str(e)
            )

        cursor.close()
        conn.close()

    # =========================
    # REFRESH BUTTON
    # =========================

    tk.Button(
        win,
        text="Refresh",
        width=15,
        command=load_tickets
    ).pack(
        pady=5
    )

    load_tickets()


# =========================================================
# CANCEL TICKET
# =========================================================

def cancel_ticket():

    win = tk.Toplevel()

    win.title("Cancel Ticket")

    win.geometry("600x450")

    win.resizable(False, False)

    # =========================
    # TITLE
    # =========================

    tk.Label(
        win,
        text="CANCEL TICKET",
        font=("Arial", 20, "bold")
    ).pack(pady=30)

    # =========================
    # BOOKING ID
    # =========================

    tk.Label(
        win,
        text="Enter Booking ID",
        font=("Arial", 12)
    ).pack(pady=10)

    booking_entry = tk.Entry(
        win,
        width=30,
        font=("Arial", 12)
    )

    booking_entry.pack(pady=10)

    # =========================
    # CANCEL FUNCTION
    # =========================

    def cancel():

        booking_id = booking_entry.get().strip()

        if booking_id == "":

            messagebox.showwarning(
                "Warning",
                "Please enter Booking ID."
            )

            return

        conn = get_connection()

        if conn is None:
            return

        cursor = conn.cursor()

        try:

            # =========================
            # CHECK BOOKING
            # =========================

            cursor.execute(
                """
                SELECT
                    booking_id,
                    status
                FROM bookings
                WHERE booking_id = %s
                """,
                (booking_id,)
            )

            result = cursor.fetchone()

            if result is None:

                messagebox.showerror(
                    "Error",
                    "Booking ID not found."
                )

                cursor.close()
                conn.close()

                return

            # =========================
            # ALREADY CANCELLED
            # =========================

            if result[1] == "Cancelled":

                messagebox.showwarning(
                    "Warning",
                    "This ticket is already cancelled."
                )

                cursor.close()
                conn.close()

                return

            # =========================
            # CONFIRM
            # =========================

            confirm = messagebox.askyesno(
                "Confirm Cancellation",
                "Are you sure you want to cancel this ticket?"
            )

            if not confirm:

                cursor.close()
                conn.close()

                return

            # =========================
            # UPDATE STATUS
            # =========================

            cursor.execute(
                """
                UPDATE bookings

                SET status = 'Cancelled'

                WHERE booking_id = %s
                """,
                (booking_id,)
            )

            conn.commit()

            messagebox.showinfo(
                "Success",
                "Ticket cancelled successfully."
            )

            booking_entry.delete(
                0,
                tk.END
            )

        except Exception as e:

            conn.rollback()

            messagebox.showerror(
                "Error",
                str(e)
            )

        cursor.close()
        conn.close()

    # =========================
    # CANCEL BUTTON
    # =========================

    tk.Button(
        win,
        text="CANCEL TICKET",
        width=20,
        height=2,
        font=("Arial", 11, "bold"),
        command=cancel
    ).pack(pady=25)