import tkinter as tk
from tkinter import messagebox


def open_dashboard():

    root = tk.Tk()

    root.title(
        "Railway Management System - Dashboard"
    )

    root.geometry("1000x650")

    root.configure(
        bg="#f2f2f2"
    )

    # =========================
    # HEADER
    # =========================

    header = tk.Frame(
        root,
        bg="#1f2937",
        height=80
    )

    header.pack(
        fill="x"
    )

    title = tk.Label(
        header,
        text="🚆 RAILWAY MANAGEMENT SYSTEM",
        bg="#1f2937",
        fg="white",
        font=("Arial", 24, "bold")
    )

    title.pack(
        pady=20
    )

    # =========================
    # MAIN FRAME
    # =========================

    frame = tk.Frame(
        root,
        bg="#f2f2f2"
    )

    frame.pack(
        pady=40
    )

    # =========================
    # BUTTONS
    # =========================

    buttons = [

        (
            "Station Management",
            station_management
        ),

        (
            "Train Management",
            train_management
        ),

        (
            "Route Management",
            route_management
        ),

        (
            "Schedule Management",
            schedule_management
        ),

        (
            "Passenger Management",
            passenger_management
        ),

        (
            "Ticket Booking",
            ticket_booking
        ),

        (
            "Search Train",
            search_train
        ),

        (
            "Ticket Information",
            ticket_information
        ),

        (
            "Cancel Ticket",
            cancel_ticket
        ),

        (
            "Reports",
            reports
        )

    ]

    row = 0
    col = 0

    for text, command in buttons:

        button = tk.Button(
            frame,
            text=text,
            width=25,
            height=3,
            font=("Arial", 11, "bold"),
            command=command
        )

        button.grid(
            row=row,
            column=col,
            padx=15,
            pady=15
        )

        col += 1

        if col == 2:

            col = 0

            row += 1


    # =========================
    # EXIT
    # =========================

    tk.Button(
        root,
        text="EXIT",
        width=20,
        height=2,
        command=root.destroy
    ).pack(
        pady=10
    )

    root.mainloop()


# =========================
# TEMPORARY FUNCTIONS
# =========================

def station_management():

    import station

    station.open_station()


def train_management():

    import train

    train.open_train()


def route_management():

    import route

    route.open_route()


def schedule_management():

    import schedule

    schedule.open_schedule()


def passenger_management():

    import passenger

    passenger.open_passenger()


def ticket_booking():

    import booking

    booking.open_booking()


def search_train():

    import ticket

    ticket.search_train()


def ticket_information():

    import ticket

    ticket.view_tickets()


def cancel_ticket():

    import ticket

    ticket.cancel_ticket()


def reports():

    import report

    report.open_report()