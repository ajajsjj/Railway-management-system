import tkinter as tk
from tkinter import ttk, messagebox
from database import get_connection


def open_station():

    win = tk.Toplevel()
    win.title("Station Management")
    win.geometry("900x600")
    win.resizable(False, False)

    # =========================
    # TITLE
    # =========================

    tk.Label(
        win,
        text="STATION MANAGEMENT",
        font=("Arial", 20, "bold")
    ).pack(pady=15)

    # =========================
    # FORM
    # =========================

    form = tk.Frame(win)
    form.pack(pady=10)

    tk.Label(
        form,
        text="Station Name"
    ).grid(row=0, column=0, padx=10, pady=8)

    name_entry = tk.Entry(
        form,
        width=30
    )
    name_entry.grid(row=0, column=1, padx=10)

    tk.Label(
        form,
        text="City"
    ).grid(row=1, column=0, padx=10, pady=8)

    city_entry = tk.Entry(
        form,
        width=30
    )
    city_entry.grid(row=1, column=1, padx=10)

    # =========================
    # TREEVIEW
    # =========================

    columns = (
        "ID",
        "Station Name",
        "City"
    )

    table = ttk.Treeview(
        win,
        columns=columns,
        show="headings",
        height=15
    )

    for col in columns:

        table.heading(
            col,
            text=col
        )

        table.column(
            col,
            width=250
        )

    table.pack(pady=15)

    # =========================
    # LOAD DATA
    # =========================

    def load_data():

        for item in table.get_children():
            table.delete(item)

        conn = get_connection()

        if conn is None:
            return

        cursor = conn.cursor()

        cursor.execute(
            """
            SELECT station_id,
                   station_name,
                   city
            FROM stations
            ORDER BY station_id
            """
        )

        rows = cursor.fetchall()

        for row in rows:

            table.insert(
                "",
                tk.END,
                values=row
            )

        cursor.close()
        conn.close()

    # =========================
    # CLEAR
    # =========================

    def clear():

        name_entry.delete(
            0,
            tk.END
        )

        city_entry.delete(
            0,
            tk.END
        )

    # =========================
    # ADD
    # =========================

    def add_station():

        name = name_entry.get().strip()
        city = city_entry.get().strip()

        if name == "" or city == "":

            messagebox.showwarning(
                "Warning",
                "Please enter station name and city."
            )

            return

        conn = get_connection()

        if conn is None:
            return

        cursor = conn.cursor()

        cursor.execute(
            """
            INSERT INTO stations
            (station_name, city)
            VALUES (%s, %s)
            """,
            (name, city)
        )

        conn.commit()

        cursor.close()
        conn.close()

        messagebox.showinfo(
            "Success",
            "Station added successfully."
        )

        clear()
        load_data()

    # =========================
    # SELECT
    # =========================

    def select_station(event):

        selected = table.focus()

        if selected == "":
            return

        values = table.item(
            selected,
            "values"
        )

        clear()

        name_entry.insert(
            0,
            values[1]
        )

        city_entry.insert(
            0,
            values[2]
        )

    # =========================
    # UPDATE
    # =========================

    def update_station():

        selected = table.focus()

        if selected == "":

            messagebox.showwarning(
                "Warning",
                "Select a station first."
            )

            return

        values = table.item(
            selected,
            "values"
        )

        station_id = values[0]

        name = name_entry.get().strip()
        city = city_entry.get().strip()

        if name == "" or city == "":
            return

        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute(
            """
            UPDATE stations
            SET station_name=%s,
                city=%s
            WHERE station_id=%s
            """,
            (name, city, station_id)
        )

        conn.commit()

        cursor.close()
        conn.close()

        messagebox.showinfo(
            "Success",
            "Station updated successfully."
        )

        clear()
        load_data()

    # =========================
    # DELETE
    # =========================

    def delete_station():

        selected = table.focus()

        if selected == "":

            messagebox.showwarning(
                "Warning",
                "Select a station first."
            )

            return

        values = table.item(
            selected,
            "values"
        )

        station_id = values[0]

        answer = messagebox.askyesno(
            "Confirm",
            "Are you sure you want to delete this station?"
        )

        if not answer:
            return

        conn = get_connection()
        cursor = conn.cursor()

        try:

            cursor.execute(
                """
                DELETE FROM stations
                WHERE station_id=%s
                """,
                (station_id,)
            )

            conn.commit()

            messagebox.showinfo(
                "Success",
                "Station deleted successfully."
            )

        except Exception as e:

            conn.rollback()

            messagebox.showerror(
                "Error",
                str(e)
            )

        cursor.close()
        conn.close()

        clear()
        load_data()

    # =========================
    # BUTTONS
    # =========================

    buttons = tk.Frame(win)
    buttons.pack()

    tk.Button(
        buttons,
        text="Add",
        width=15,
        command=add_station
    ).grid(row=0, column=0, padx=5)

    tk.Button(
        buttons,
        text="Update",
        width=15,
        command=update_station
    ).grid(row=0, column=1, padx=5)

    tk.Button(
        buttons,
        text="Delete",
        width=15,
        command=delete_station
    ).grid(row=0, column=2, padx=5)

    tk.Button(
        buttons,
        text="Clear",
        width=15,
        command=clear
    ).grid(row=0, column=3, padx=5)

    table.bind(
        "<ButtonRelease-1>",
        select_station
    )

    load_data()