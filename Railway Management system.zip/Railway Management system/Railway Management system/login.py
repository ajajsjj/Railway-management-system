import tkinter as tk
from tkinter import messagebox

from database import get_connection


class LoginWindow:

    def __init__(self, root):

        self.root = root

        self.root.title(
            "Railway Management System - Login"
        )

        self.root.geometry("500x400")

        self.root.resizable(False, False)

        # =========================
        # TITLE
        # =========================

        title = tk.Label(
            root,
            text="RAILWAY MANAGEMENT SYSTEM",
            font=("Arial", 20, "bold")
        )

        title.pack(pady=40)

        # =========================
        # USERNAME
        # =========================

        tk.Label(
            root,
            text="Username",
            font=("Arial", 12)
        ).pack()

        self.username = tk.Entry(
            root,
            width=35,
            font=("Arial", 12)
        )

        self.username.pack(pady=10)

        # =========================
        # PASSWORD
        # =========================

        tk.Label(
            root,
            text="Password",
            font=("Arial", 12)
        ).pack()

        self.password = tk.Entry(
            root,
            width=35,
            show="*",
            font=("Arial", 12)
        )

        self.password.pack(pady=10)

        # =========================
        # LOGIN BUTTON
        # =========================

        tk.Button(
            root,
            text="LOGIN",
            width=20,
            height=2,
            command=self.login
        ).pack(pady=25)


    def login(self):

        username = self.username.get()

        password = self.password.get()

        if username == "" or password == "":

            messagebox.showwarning(
                "Warning",
                "Please enter username and password."
            )

            return

        connection = get_connection()

        if connection is None:

            messagebox.showerror(
                "Error",
                "Database connection failed."
            )

            return

        cursor = connection.cursor()

        query = """
        SELECT user_id, username, role
        FROM users
        WHERE username=%s
        AND password=%s
        """

        cursor.execute(
            query,
            (username, password)
        )

        result = cursor.fetchone()

        cursor.close()

        connection.close()

        if result:

            messagebox.showinfo(
                "Login Successful",
                "Welcome " + username
            )

            self.root.destroy()

            import dashboard

            dashboard.open_dashboard()

        else:

            messagebox.showerror(
                "Login Failed",
                "Invalid username or password."
            )