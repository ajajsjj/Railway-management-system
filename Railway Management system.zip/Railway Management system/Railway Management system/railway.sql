CREATE DATABASE IF NOT EXISTS railway_management;

USE railway_management;

DROP TABLE IF EXISTS bookings;
DROP TABLE IF EXISTS schedules;
DROP TABLE IF EXISTS routes;
DROP TABLE IF EXISTS passengers;
DROP TABLE IF EXISTS trains;
DROP TABLE IF EXISTS stations;
DROP TABLE IF EXISTS users;


-- =========================
-- USERS
-- =========================

CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(100) NOT NULL,
    role VARCHAR(20) DEFAULT 'admin'
);

INSERT INTO users(username, password, role)
VALUES ('admin', '1234', 'admin');


-- =========================
-- STATIONS
-- =========================

CREATE TABLE stations (
    station_id INT AUTO_INCREMENT PRIMARY KEY,
    station_name VARCHAR(100) NOT NULL,
    city VARCHAR(100) NOT NULL
);


-- =========================
-- TRAINS
-- =========================

CREATE TABLE trains (
    train_id INT AUTO_INCREMENT PRIMARY KEY,
    train_no VARCHAR(20) NOT NULL UNIQUE,
    train_name VARCHAR(100) NOT NULL,
    train_type VARCHAR(50) NOT NULL,
    total_seats INT NOT NULL
);


-- =========================
-- ROUTES  (distance column included — required by route.py)
-- =========================

CREATE TABLE routes (
    route_id INT AUTO_INCREMENT PRIMARY KEY,
    source_id INT NOT NULL,
    destination_id INT NOT NULL,
    distance FLOAT DEFAULT 0,

    FOREIGN KEY (source_id)
        REFERENCES stations(station_id)
        ON DELETE CASCADE,

    FOREIGN KEY (destination_id)
        REFERENCES stations(station_id)
        ON DELETE CASCADE
);


-- =========================
-- SCHEDULES
-- =========================

CREATE TABLE schedules (
    schedule_id INT AUTO_INCREMENT PRIMARY KEY,

    train_id INT NOT NULL,
    route_id INT NOT NULL,

    travel_date DATE NOT NULL,
    departure_time TIME NOT NULL,
    arrival_time TIME NOT NULL,

    FOREIGN KEY (train_id)
        REFERENCES trains(train_id)
        ON DELETE CASCADE,

    FOREIGN KEY (route_id)
        REFERENCES routes(route_id)
        ON DELETE CASCADE
);


-- =========================
-- PASSENGERS
-- =========================

CREATE TABLE passengers (
    passenger_id INT AUTO_INCREMENT PRIMARY KEY,
    passenger_name VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    email VARCHAR(100)
);


-- =========================
-- BOOKINGS
-- =========================

CREATE TABLE bookings (
    booking_id INT AUTO_INCREMENT PRIMARY KEY,

    passenger_id INT NOT NULL,
    schedule_id INT NOT NULL,

    seat_no VARCHAR(20) NOT NULL,
    booking_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    amount DECIMAL(10,2) NOT NULL,

    status VARCHAR(20) DEFAULT 'Confirmed',

    FOREIGN KEY (passenger_id)
        REFERENCES passengers(passenger_id)
        ON DELETE CASCADE,

    FOREIGN KEY (schedule_id)
        REFERENCES schedules(schedule_id)
        ON DELETE CASCADE
);


-- =========================
-- SAMPLE STATIONS
-- =========================

INSERT INTO stations(station_name, city)
VALUES
('Dhaka Railway Station', 'Dhaka'),
('Chittagong Railway Station', 'Chittagong'),
('Sylhet Railway Station', 'Sylhet'),
('Rajshahi Railway Station', 'Rajshahi'),
('Khulna Railway Station', 'Khulna'),
('Mymensingh Railway Station', 'Mymensingh');


-- =========================
-- SAMPLE TRAINS
-- =========================

INSERT INTO trains
(train_no, train_name, train_type, total_seats)
VALUES
('701', 'Subarna Express', 'Intercity', 500),
('703', 'Mohanagar Express', 'Intercity', 450),
('705', 'Upukol Express', 'Intercity', 400),
('707', 'Silk City Express', 'Intercity', 450),
('709', 'Tista Express', 'Intercity', 400);


-- =========================
-- SAMPLE ROUTES (with distance)
-- =========================

INSERT INTO routes(source_id, destination_id, distance)
VALUES
(1,2, 264),
(1,3, 247),
(1,4, 256),
(1,5, 334),
(1,6, 120);


-- =========================
-- SAMPLE SCHEDULES
-- =========================

INSERT INTO schedules
(train_id, route_id, travel_date, departure_time, arrival_time)
VALUES
(1,1,'2026-09-20','07:00:00','13:00:00'),
(2,2,'2026-09-20','08:00:00','15:00:00'),
(4,3,'2026-09-21','09:00:00','14:00:00'),
(3,4,'2026-09-22','06:30:00','12:00:00'),
(5,5,'2026-09-23','07:30:00','12:30:00');


-- =========================
-- SAMPLE PASSENGERS
-- =========================

INSERT INTO passengers
(passenger_name, phone, email)
VALUES
('Rahim Ahmed','01711111111','rahim@gmail.com'),
('Karim Hasan','01822222222','karim@gmail.com'),
('Nusrat Jahan','01933333333','nusrat@gmail.com');